# WildCatch
#### Capture the Moment... / Conserve the Future...

## About The Project
This app identifies animals from photos and provides information about them, including fun facts. It has an intuitive interface and machine learning model trained on 63 species. The app aims to raise awareness about wildlife and encourage appreciation for the diversity of life on our planet.

## Built With

* SwiftUI
* CoreML
* Vision

## Files with Unsplash License: <br />
**Amur Leopard:** Photo by Gwen Weustink on [Unsplash]( https://unsplash.com/photos/I3C1sSXj1i8?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br /> 
**Javan Rhino:** Photo by LOGAN WEAVER | @LGNWVR on [Unsplash]( https://unsplash.com/photos/dj_46kowMqc?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Sumatran Orangutan:** Photo by Steffen B. on [Unsplash]( https://unsplash.com/photos/8uAUM_pod4g?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Polar Bear:** Photo by Hans-Jurgen Mager on [Unsplash]( https://unsplash.com/photos/KgRKlQXmHR0?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Walrus:** Photo by LOREMIPSUM on [Unsplash]( https://unsplash.com/photos/h13Y8vyIXNU?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Cat:** Photo by Jay Ruzesky on [Unsplash]( https://unsplash.com/photos/gKXKBY-C-Dk?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Dog:** Photo by Victor Grabarczyk on [Unsplash]( https://unsplash.com/photos/N04FIfHhv_k?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Dolphin:** Photo by Ranae Smith on [Unsplash]( https://unsplash.com/photos/fgKEqVzX5zM?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Giant Panda:** Photo by Sid Balachandran on [Unsplash]( https://unsplash.com/photos/_9a-3NO5KJE?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Lion:** Photo by Zdeněk Macháček on [Unsplash]( https://unsplash.com/photos/UxHol6SwLyM?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Mountain Gorilla:** Photo by Bob Brewer on [Unsplash]( https://unsplash.com/photos/lV5PT7R-RuE?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**European Rabbit:** Photo by Gary Bendig on [Unsplash]( https://unsplash.com/photos/KvHT4dltPEQ?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Red Panda:** Photo by Jessica Weiller on [Unsplash]( https://unsplash.com/photos/GAw5wFLVWVo?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Scimitar Oryx:** Photo by Geraldine Dukes on [Unsplash]( https://unsplash.com/photos/35vA1XWe-BM?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Sea Turtle:** Photo by Kris-Mikael Krister on [Unsplash]( https://unsplash.com/photos/aGihPIbrtVE?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Snow Leopard:** Photo by Robert Sachowski on [Unsplash]( https://unsplash.com/photos/HFIvhaOcHVA?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Sunda Tiger:** Photo by Javier Virues-Ortega on [Unsplash]( https://unsplash.com/photos/xWg2JqRmitI?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Humpback Whale:** Photo by Gabriel Dizzi on [Unsplash]( https://unsplash.com/photos/WPXxp36tkHQ?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Hamster:** Photo by Frenjamin Benklin on [Unsplash]( https://unsplash.com/photos/KIXHGKPswE0?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Blue Shark:** Photo by David Clode on [Unsplash]( https://unsplash.com/photos/o3r7oVPZnZI?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Brown Bear:** Photo by Nidal Shbeeb on [Unsplash]( https://unsplash.com/photos/iT9Axx176qw?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Capybara:** Photo by Dušan veverkolog on [Unsplash]( https://unsplash.com/photos/yObnHvuwkiY?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Cheetah:** Photo by David Groves on [Unsplash]( https://unsplash.com/photos/bcJUbYd5gTo?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Clownfish:** Photo by Anthony Rao on [Unsplash]( https://unsplash.com/photos/MXj8mrLXWKY?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Common Garter Snake:** Photo by Duncan Sanchez on [Unsplash]( https://unsplash.com/photos/l6aAMUH_oW8?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Crocodile:** Photo by Rae Wallis on [Unsplash]( https://unsplash.com/photos/0P0_fMu-XFs?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Deer:** Photo by Diana Parkhouse on [Unsplash]( https://unsplash.com/photos/Y7mzlRgkF4I?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Fox:** Photo by Ray Hennessy on [Unsplash]( https://unsplash.com/photos/xUUZcpQlqpM?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Flamingo:** Photo by Lex Melony on [Unsplash]( https://unsplash.com/photos/5JB_c7BAdvM?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Giraffe:** Photo by Damian Patkowski on [Unsplash]( https://unsplash.com/photos/JRjod5VG0V0?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Goldfish:** Photo by Antoine Peltier on [Unsplash]( https://unsplash.com/photos/nz2hUsnlyLc?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Grass Frog:** Photo by Silvan Rüegg on [Unsplash]( https://unsplash.com/photos/BYdJ_aneCeo?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Green Iguana:** Photo by Daniela Turcanu on [Unsplash]( https://unsplash.com/photos/K8eHnMFG1Zc?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Hyena:** Photo by James Botes on [Unsplash]( https://unsplash.com/photos/HZvF_ZKSSWA?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Jaguar:** Photo by CHUTTERSNAP on [Unsplash]( https://unsplash.com/photos/MpxAiNDevjU?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Kangaroo:** Photo by Carles Rabada on [Unsplash]( https://unsplash.com/photos/v3v6uz-n-pQ?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Koala:** Photo by Jordan Whitt on [Unsplash]( https://unsplash.com/photos/EerxztHCjM8?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Mouse:** Photo by Joshua J. Cotten on [Unsplash]( https://unsplash.com/photos/CvuYZA8fsxU?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Octupus:** Photo by Diane Picchiottino on [Unsplash]( https://unsplash.com/photos/dW0gfo__uU8?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Panther Chameleon:** Photo by Pierre Bamin on [Unsplash]( https://unsplash.com/photos/eh_Q3gHA8gM?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Budgerigar:** Photo by Dalton Touchberry on [Unsplash]( https://unsplash.com/photos/yWfdhaqSAEo?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Sloth:** Photo by Deb Dowd on [Unsplash]( https://unsplash.com/photos/Tw8yUiNvwnc?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Toucan:** Photo by Rico Meier on [Unsplash]( https://unsplash.com/photos/pmQRO5YcKCk?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Zebra:** Photo by Ron Dauphin on [Unsplash]( https://unsplash.com/photos/k-8-eX4Y3no?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Black Widow Spider:** Photo by Tom Sid on [Unsplash]( https://unsplash.com/photos/-9W8G_O4w8g?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Otters:** Photo by Anchor Lee on [Unsplash]( https://unsplash.com/photos/pk7YVlj6o2o?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Monarch Butterfly:** Photo by Erin Minuskin on [Unsplash]( https://unsplash.com/photos/LGaneK6yG9M?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Horse:** Photo by Silje Midtgård on [Unsplash]( https://unsplash.com/photos/0F9oVQ3x2ak?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Pig:** Photo by Nicolas Castez on [Unsplash]( https://unsplash.com/photos/5APBLfC2hUs?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Cow:** Photo by Andy Kelly on [Unsplash]( https://unsplash.com/photos/5APBLfC2hUs?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Goat:** Photo by Nandhu Kumar on [Unsplash]( https://unsplash.com/photos/jAMcUbsTvWE?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />
**Sheep:** Photo by John Fowler on [Unsplash]( https://unsplash.com/photos/jmYJBQXvLNI?utm_source=unsplash&utm_medium=referral&utm_content=creditShareLink) <br />

## Files with Attribution-ShareAlike 4.0 International (CC BY-SA 4.0): <br />
**Iberian Lynx:** Diego Delso. Iberian Lynx (Lynx pardinus), Almuradiel, Ciudad Real, Spain. 19 December 2021, 18:01:45. Retrieved from [Wikipedia Commons]( https://commons.wikimedia.org/wiki/File:Lince_ibérico_(Lynx_pardinus),_Almuradiel,_Ciudad_Real,_España,_2021-12-19,_DD_07.jpg) <br />
**Hippopotamus:** Muhammad Mahdi Karim. Portrait of a Hippopotamus in water in Saadani National Park. 6 September 2020. Retrieved from [Wikipedia Commons]( https://commons.wikimedia.org/wiki/File:Portrait_Hippopotamus_in_the_water.jpg#/media/File:Portrait_Hippopotamus_in_the_water.jpg) <br />

## Files with Attribution-ShareAlike 3.0 Unported (CC BY-SA 3.0): <br />
**Galápagos Penguin:** Charles J. Sharp. Male adult Galápagos penguin (Spheniscus mendiculus) swimming on Isabela Island off Moreno Point, Galapagos Islands. 26 March 2012. Retrieved from [Wikipedia Commons](https://en.wikipedia.org/wiki/File:Galápagos_penguin_(Spheniscus_mendiculus)_male.jpg) <br />
**Black Panther:** Rute Martins of Leoa's Photography. Black Panther. Photo taken at Rhino and Lion Park, Gauteng, South Africa. 25 February 2010. Retrieved from [Wikipedia Commons]( https://commons.wikimedia.org/wiki/File:Black_Panther.JPG#/media/File:Black_Panther.JPG) <br />

## Files with Attribution 2.5 Generic (CC BY 2.5): <br />
**African Forest Elephant:** Thomas Breuer. Forest elephants (Loxodonta cyclotis) in the swamp Mbeli Bai, Nouabalé-Ndoki National Park, Congo. 2 March 2007. Retrieved from [Wikipedia Commons]( https://commons.wikimedia.org/wiki/File:Loxodontacyclotis.jpg#/media/File:Loxodontacyclotis.jpg) <br />

## Files with Attribution 2.0 Generic (CC BY 2.0): <br />
**Adélie Penguin:** Jason Auch. Adelie Penguins (Pygoscelis adeliae) on iceberg. 30 December 2008. Retrieved from [Wikipedia Commons]( https://commons.wikimedia.org/wiki/File:Adelie_Penguins_on_iceberg.jpg#/media/File:Adelie_Penguins_on_iceberg.jpg) <br />
**Amazon River Dolphin:** Oceancetaceen. Amazonas-Flussdelphin: Orinoko im Zoo Duisburg. 9 July 2008. Retrieved from [Wikipedia Commons]( https://commons.wikimedia.org/wiki/File:Amazonas-Flussdelfin_Orinoko3.jpg#/media/File:Amazonas-Flussdelfin_Orinoko3.jpg) <br />
**Emperor Penguin:** Christopher Michel. An Emperor Penguin (Aptenodytes forsteri) in Antarctica jumping out of the water. 3 December 2013. Retrieved from [Wikipedia Commons]( https://commons.wikimedia.org/wiki/File:Penguin_in_Antarctica_jumping_out_of_the_water.jpg#/media/File:Penguin_in_Antarctica_jumping_out_of_the_water.jpg) <br />
**Spix's Macaw:** Rüdiger Stehn. A Spix's Macaw in Vogelpark Walsrode, Walsrode, Germany in about 1980. 1 January 1980. Retrieved from [Wikipedia Commons]( https://commons.wikimedia.org/wiki/File:Cyanopsitta_spixii_-Vogelpark_Walsrode,_Walsrode,_Germany-1980.jpg#/media/File:Cyanopsitta_spixii_-Vogelpark_Walsrode,_Walsrode,_Germany-1980.jpg) <br />

## Files with Public Domain License: <br />
**Pyrenean Ibex:** Joseph Wolf. Plate 22 (Spanish Tur) from the book 'Wild oxen, sheep & goats of all lands, living and extinct' (1898) by Richard Lydekker. 1898. Retrieved from [Wikipedia Commons]( https://commons.wikimedia.org/wiki/File:Pyrenean_Ibex.png) <br />


## About the Licenses:
**Unsplash Licence:** Images with the Unsplash License are free to use without any attribution or permission required. These images are released under the Creative Commons CC0 license, which allows for their use in both personal and commercial projects. They can also be modified, distributed, and copied without any restrictions. <br />  <br /> 
**Attribution-ShareAlike 4.0 International (CC BY-SA 4.0):** This license requires the user to give credit to the author of the image and to share the image under the same license as the original. The images can be used for commercial or personal purposes and can be modified, distributed, and copied as long as the conditions of the license are met. <br />  <br /> 
**Attribution-ShareAlike 3.0 Unported (CC BY-SA 3.0):** This license is similar to CC BY-SA 4.0, but it is an older version of the license. It requires the user to give credit to the author and to share the image under the same license. The images can be used for commercial or personal purposes and can be modified, distributed, and copied as long as the conditions of the license are met. <br />  <br /> 
**Attribution 2.5 Generic (CC BY 2.5):** This license allows the user to modify, distribute, and copy the image for commercial or personal purposes. However, it requires the user to give credit to the author of the image. <br />  <br /> 
**Attribution 2.0 Generic (CC BY 2.0):** This license is similar to CC BY 2.5, but it is an older version of the license. It allows the user to modify, distribute, and copy the image for commercial or personal purposes, but it also requires the user to give credit to the author of the image. <br />  <br /> 
**Public Domain:** Public domain refers to creative works that are not protected by copyright or any other legal restrictions, which means that they are free for anyone to use, modify, and distribute without asking for permission or giving credit. <br />  <br /> 
